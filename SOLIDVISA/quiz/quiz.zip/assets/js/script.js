
$(document).ready(() => {
	console.log('ready');
});
